<!DOCTYPE>
<html>
<head>
	<title>Forget Password</title>
</head>
<body>
	<table>
		<div>
				<div>
				<table align="center" width="100%">
					<tr align="right">
						<td width="10%">
							<a href="Home.php"><img src="images/logos.png" align="left"></a>
						</td>
						<td width="30%">&nbsp;</td>
						<td align="center" width="10%">
							<fieldset><a href="Home.php" >Home <img src="images/home.png"></a></fieldset>
						</td>
						<td width="10%" align="center">
							<fieldset><a href="Registration.php">Registration<img src="images/registration.png"></a></fieldset>
						</td>
						<td width="10%" align="center">
							<fieldset><a href="service.php">Our Service<img src="images/service.png"></a></fieldset>
						</td>
						<td width="10%" align="center">
							<fieldset><a href="Login.php">Login<img src="images/login.png"></a></fieldset>
						</td>
					</tr>
				</table>
		</div>

       
<div>
	<table align="center" width="60%">
		<tr>
			<td>
				<h1 align="center">Reset Password</h1>
				<fieldset>	
				<table align="center">
					<tr>
						<td><label>User Name</label></td>
						<td>:</td>
						<td><input type="name" name="name"/></td>
						<td><img src="images/person.png"></td>
					</tr>
					<tr>
						<td><label>Email</label></td>
						<td>:</td>
						<td><input type="email" name="email"/></td>
						<td><img src="images/message.png"></td>
					</tr>
					<tr><td><br></td></tr>
					<tr><td align="center" colspan="3"><input type="submit" value="Reset Password"/></td></tr>
					<tr><td colspan="3" align="center"><a href="Login.php">Back To Login</a></td></tr></td></tr>	
					
				</table>
				</fieldset>
			</td>
		</tr>
	</table>
</div>

<div>
		<table align="center">
			<tr align="center">
				<td>
				<a href="https://www.facebook.com/">
				<img src="images/facebook.png">
                 </a>
             </td>
				<td>
						<a href="https://www.twitter.com/">
						<img src="images/twitter.png">
					</a>
				</td>
			</tr>
		</table>
		
		<table align="center">
			<tr>
				<td align="center" colspan="3">
				<a href="About_Us.php">About Us   </a>
			</td>
			<td align="center" colspan="3">
				<a href="Contact_Us.php">Contact Us   </a>
			</td>
			<td align="center" colspan="3">
				<a href="privacyPolicy.php">Privacy Policy   </a>
			</td>
			<td align="center" colspan="3">
				<a href="faq.php">FAQ</a>
			</td>
			</tr>
		</table>
	</div>
    <div>
<table align="center" width="100%" border="1">
<tr>
<td align="center" colspan="3">
<b>&copy;2017 Psycho-Therapy. All rights reserved</b>
</td>
</tr>
</table>
</div>