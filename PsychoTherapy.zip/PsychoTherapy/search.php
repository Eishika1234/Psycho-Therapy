<?php

<?php 
    session_start();

if(!isset($_SESSION['patient_username']) || empty($_SESSION['patient_username'])){
		  header("location: ../Login.php");
		  
		}
else {
	
    
	
   // connect to db
//fetching data in descending order (lastest entry first)
    $sterm=$_GET['search'];
	//echo $sterm;
  	$sql = "SELECT * FROM doctor where (username LIKE '%$sterm%') order by id DESC";
	$con = mysqli_connect("localhost", "root", "", "mediportal_db");
	
	$rs_result = mysqli_query ($con,$sql);
	if (!$con) {
		die("Connection failed: " . mysqli_connect_error());
	} 
	$totalres=mysqli_num_rows($rs_result);
}


echo "<script src='func/search.js'></script>
<table class='table table-striped table-bordered table-condensed'>
<tr>
<td colspan='4' class='alert alert-success'>
	<h3>Total '$totalres' Results Found</h3>
</td>
<td colspan='4'>
<form method='get' action='search.php' style='float:right'>
<input type='text' name='search' placeholder='search' class='input-sm' value='$sterm' onkeyup='showResultSrch(this.value)'/>
<input type='submit' value='Search' class='tn btn-success'/>
</form>
</td>
</tr>
    <tr>
        <th>Name</th>
        <th>Gender</th>
        <th>Email</th>
        <th>Date of Birth</th>
    </tr>";
    
    while($res=mysqli_fetch_array($rs_result)) {
        echo "<tr>";
        echo "<td><input type='radio' name='user' value=".$res['username'].">".$res['name']."</td>";
		echo "<td>".$res['gender']."</td>";
		echo "<td>".$res['email']."</td>";
		echo "<td>".$res['dob']."</td>";       
    }

 
echo "</table>";

    //close db connection
?>

